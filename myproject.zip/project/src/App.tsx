import { useState } from "react";
import Home from "@/components/Home";
import StudyInterface from "@/components/StudyInterface";

type View = "home" | "study";

export default function App() {
  const [view, setView] = useState<View>("home");

  return view === "home" ? (
    <Home onStart={() => setView("study")} />
  ) : (
    <StudyInterface onBack={() => setView("home")} />
  );
}
