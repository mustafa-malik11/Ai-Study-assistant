import { GraduationCap, Sparkles, BookOpen, Lightbulb, HelpCircle, ArrowRight } from "lucide-react";

interface HomeProps {
  onStart: () => void;
}

const features = [
  {
    icon: BookOpen,
    title: "Simple Explanations",
    description: "Complex topics broken down into clear, student-friendly language.",
  },
  {
    icon: Lightbulb,
    title: "Real-World Examples",
    description: "See how each concept shows up in everyday life to make it stick.",
  },
  {
    icon: HelpCircle,
    title: "Practice Quizzes",
    description: "Five auto-generated quiz questions to test your understanding.",
  },
];

export default function Home({ onStart }: HomeProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100">
      <div className="mx-auto max-w-6xl px-6">
        {/* Header */}
        <header className="flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/20">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <span className="text-lg font-semibold text-slate-800">AI Study Assistant</span>
          </div>
          <button
            onClick={onStart}
            className="hidden items-center gap-1.5 rounded-full bg-slate-900 px-5 py-2.5 text-sm font-medium text-white transition-all hover:bg-slate-700 hover:shadow-lg sm:flex"
          >
            Start Studying <ArrowRight className="h-4 w-4" />
          </button>
        </header>

        {/* Hero */}
        <section className="flex flex-col items-center pt-16 pb-20 text-center sm:pt-24">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-1.5 text-sm font-medium text-emerald-700">
            <Sparkles className="h-4 w-4" />
            Powered by AI
          </div>
          <h1 className="mt-6 max-w-3xl text-4xl font-bold leading-tight tracking-tight text-slate-900 sm:text-6xl">
            Understand anything with your{" "}
            <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              AI Study Assistant
            </span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-slate-600">
            Struggling with a tough topic? Get a clear explanation, a real-world example, and five
            practice questions in seconds. Learning complex subjects shouldn't require a tutor on
            call — now it doesn't.
          </p>
          <button
            onClick={onStart}
            className="mt-10 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-emerald-600 to-teal-600 px-8 py-4 text-base font-semibold text-white shadow-xl shadow-emerald-500/30 transition-all hover:scale-[1.03] hover:shadow-2xl hover:shadow-emerald-500/40"
          >
            Try it now <ArrowRight className="h-5 w-5" />
          </button>
        </section>

        {/* Problem */}
        <section className="mx-auto max-w-3xl rounded-3xl border border-slate-200 bg-white p-8 shadow-sm sm:p-10">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-emerald-600">
            The problem
          </h2>
          <p className="mt-3 text-lg leading-relaxed text-slate-700">
            Students often hit a wall when a textbook explanation is too dense, a lecture moves too
            fast, or a tutor isn't available. Concepts stay unclear, examples feel abstract, and
            there's no quick way to check whether the material actually sunk in.
          </p>
          <p className="mt-4 text-lg leading-relaxed text-slate-700">
            AI Study Assistant fixes this by turning any topic into a clear explanation, a concrete
            real-world example, and an instant quiz — all generated on demand.
          </p>
        </section>

        {/* Features */}
        <section className="py-20">
          <div className="grid gap-6 sm:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="group rounded-2xl border border-slate-200 bg-white p-7 transition-all hover:-translate-y-1 hover:border-emerald-200 hover:shadow-xl hover:shadow-emerald-500/5"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 transition-colors group-hover:bg-emerald-100">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-5 text-lg font-semibold text-slate-900">{feature.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-6 py-8 text-center text-sm text-slate-500">
          AI Study Assistant — built with React, Tailwind CSS, and OpenAI.
        </div>
      </footer>
    </div>
  );
}
