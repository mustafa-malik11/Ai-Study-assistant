import { GraduationCap } from "lucide-react";

export default function LoadingAnimation() {
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <div className="relative flex h-20 w-20 items-center justify-center">
        <div className="absolute h-20 w-20 animate-ping rounded-full bg-emerald-400/30" />
        <div className="absolute h-16 w-16 animate-pulse rounded-full bg-emerald-500/20" />
        <div className="relative flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/40">
          <GraduationCap className="h-6 w-6 text-white" />
        </div>
      </div>
      <p className="mt-6 text-base font-medium text-slate-700">AI is studying the topic...</p>
      <p className="mt-1 text-sm text-slate-500">Crafting an explanation, example, and quiz for you.</p>
      <div className="mt-5 flex gap-1.5">
        <span className="h-2 w-2 animate-bounce rounded-full bg-emerald-500 [animation-delay:-0.3s]" />
        <span className="h-2 w-2 animate-bounce rounded-full bg-emerald-500 [animation-delay:-0.15s]" />
        <span className="h-2 w-2 animate-bounce rounded-full bg-emerald-500" />
      </div>
    </div>
  );
}
