import { useState } from "react";
import { Check, X } from "lucide-react";
import type { QuizQuestion } from "@/types/study";

interface QuizProps {
  questions: QuizQuestion[];
}

export default function Quiz({ questions }: QuizProps) {
  const [answers, setAnswers] = useState<(number | null)[]>(questions.map(() => null));
  const [submitted, setSubmitted] = useState(false);

  const score = answers.reduce<number>(
    (acc, ans, i) => (ans !== null && ans === questions[i].answerIndex ? acc + 1 : acc),
    0
  );

  const handleSelect = (qIndex: number, optionIndex: number) => {
    if (submitted) return;
    setAnswers((prev) => {
      const next = [...prev];
      next[qIndex] = optionIndex;
      return next;
    });
  };

  const allAnswered = answers.every((a) => a !== null);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-slate-900">Practice Quiz</h3>
        {submitted && (
          <span className="rounded-full bg-emerald-50 px-3 py-1 text-sm font-semibold text-emerald-700">
            Score: {score}/{questions.length}
          </span>
        )}
      </div>

      <div className="mt-6 space-y-6">
        {questions.map((q, qIndex) => (
          <div key={qIndex} className="rounded-xl border border-slate-100 bg-slate-50/50 p-5">
            <p className="font-medium text-slate-800">
              {qIndex + 1}. {q.question}
            </p>
            <div className="mt-3 grid gap-2">
              {q.options.map((option, oIndex) => {
                const selected = answers[qIndex] === oIndex;
                const isCorrect = q.answerIndex === oIndex;
                const showCorrect = submitted && isCorrect;
                const showWrong = submitted && selected && !isCorrect;

                return (
                  <button
                    key={oIndex}
                    onClick={() => handleSelect(qIndex, oIndex)}
                    disabled={submitted}
                    className={[
                      "flex items-center justify-between rounded-lg border px-4 py-3 text-left text-sm transition-all",
                      showCorrect
                        ? "border-emerald-500 bg-emerald-50 text-emerald-800"
                        : showWrong
                          ? "border-red-400 bg-red-50 text-red-700"
                          : selected
                            ? "border-emerald-400 bg-emerald-50/60 text-slate-800"
                            : "border-slate-200 bg-white text-slate-700 hover:border-emerald-300 hover:bg-emerald-50/30",
                      submitted ? "cursor-default" : "cursor-pointer",
                    ].join(" ")}
                  >
                    <span>{option}</span>
                    {showCorrect && <Check className="h-4 w-4 text-emerald-600" />}
                    {showWrong && <X className="h-4 w-4 text-red-500" />}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {!submitted && (
        <button
          onClick={() => setSubmitted(true)}
          disabled={!allAnswered}
          className="mt-6 w-full rounded-xl bg-slate-900 py-3 text-sm font-semibold text-white transition-all hover:bg-slate-700 disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          {allAnswered ? "Submit answers" : "Answer all questions to submit"}
        </button>
      )}

      {submitted && (
        <button
          onClick={() => {
            setAnswers(questions.map(() => null));
            setSubmitted(false);
          }}
          className="mt-6 w-full rounded-xl border border-slate-300 bg-white py-3 text-sm font-semibold text-slate-700 transition-all hover:bg-slate-50"
        >
          Try again
        </button>
      )}
    </div>
  );
}
