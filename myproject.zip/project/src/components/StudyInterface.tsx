import { useState } from "react";
import {
  ArrowLeft,
  BookOpen,
  Lightbulb,
  Send,
  Copy,
  Check,
  AlertCircle,
  GraduationCap,
} from "lucide-react";
import LoadingAnimation from "./LoadingAnimation";
import Quiz from "./Quiz";
import { fetchStudyTopic } from "@/lib/ai";
import type { StudyResponse } from "@/types/study";

interface StudyInterfaceProps {
  onBack: () => void;
}

export default function StudyInterface({ onBack }: StudyInterfaceProps) {
  const [topic, setTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<StudyResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);
    setCopied(false);
    try {
      const data = await fetchStudyTopic(topic);
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!result) return;
    const text = [
      `Topic: ${topic}`,
      "",
      "Explanation:",
      result.explanation,
      "",
      "Real-World Example:",
      result.realWorldExample,
      "",
      "Quiz:",
      ...result.quiz.map(
        (q, i) =>
          `${i + 1}. ${q.question}\n${q.options.map((o, oi) => `   ${oi === q.answerIndex ? "(*)" : "( )"} ${o}`).join("\n")}`
      ),
    ].join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError("Could not copy to clipboard.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100">
      <div className="mx-auto max-w-3xl px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 transition-colors hover:text-slate-900"
          >
            <ArrowLeft className="h-4 w-4" /> Home
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600">
              <GraduationCap className="h-5 w-5 text-white" />
            </div>
            <span className="text-sm font-semibold text-slate-800">AI Study Assistant</span>
          </div>
        </div>

        {/* Search */}
        <form onSubmit={handleSubmit} className="mt-8">
          <label htmlFor="topic" className="block text-sm font-medium text-slate-700">
            What do you want to learn today?
          </label>
          <div className="mt-2 flex gap-2">
            <input
              id="topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Photosynthesis, Newton's laws, Supply and demand..."
              className="flex-1 rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-800 shadow-sm outline-none transition-all placeholder:text-slate-400 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
            />
            <button
              type="submit"
              disabled={loading || !topic.trim()}
              className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:scale-100"
            >
              <Send className="h-4 w-4" /> Explain
            </button>
          </div>
        </form>

        {/* States */}
        {loading && <LoadingAnimation />}

        {error && !loading && (
          <div className="mt-8 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 p-5 text-sm text-red-700">
            <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0" />
            <div>
              <p className="font-medium">We couldn't generate a response.</p>
              <p className="mt-1 text-red-600">{error}</p>
            </div>
          </div>
        )}

        {result && !loading && (
          <div className="mt-8 space-y-6">
            {/* Copy button */}
            <div className="flex justify-end">
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 transition-all hover:bg-slate-50"
              >
                {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copied!" : "Copy response"}
              </button>
            </div>

            {/* Explanation */}
            <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                  <BookOpen className="h-5 w-5" />
                </div>
                <h2 className="text-lg font-semibold text-slate-900">Explanation</h2>
              </div>
              <p className="mt-4 whitespace-pre-line leading-relaxed text-slate-700">
                {result.explanation}
              </p>
            </section>

            {/* Real-world example */}
            <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                  <Lightbulb className="h-5 w-5" />
                </div>
                <h2 className="text-lg font-semibold text-slate-900">Real-World Example</h2>
              </div>
              <p className="mt-4 whitespace-pre-line leading-relaxed text-slate-700">
                {result.realWorldExample}
              </p>
            </section>

            {/* Quiz */}
            <Quiz questions={result.quiz} />
          </div>
        )}

        {!loading && !result && !error && (
          <div className="mt-16 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
              <BookOpen className="h-8 w-8" />
            </div>
            <p className="mt-4 text-sm text-slate-500">
              Enter any topic above and get a clear explanation, a real-world example, and a quiz.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
