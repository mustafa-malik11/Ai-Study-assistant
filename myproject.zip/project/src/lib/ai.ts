import { AI_STUDY_FUNCTION_URL, AI_STUDY_HEADERS } from "./supabase";
import type { StudyResponse } from "@/types/study";

export async function fetchStudyTopic(topic: string): Promise<StudyResponse> {
  const response = await fetch(AI_STUDY_FUNCTION_URL, {
    method: "POST",
    headers: AI_STUDY_HEADERS,
    body: JSON.stringify({ topic }),
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const message =
      (data && typeof data === "object" && "error" in data && String(data.error)) ||
      `Request failed (${response.status})`;
    throw new Error(message);
  }

  if (!data || typeof data !== "object") {
    throw new Error("The AI service returned an unexpected response.");
  }

  const study = data as StudyResponse;
  if (
    typeof study.explanation !== "string" ||
    typeof study.realWorldExample !== "string" ||
    !Array.isArray(study.quiz)
  ) {
    throw new Error("The AI response was missing required fields.");
  }

  return study;
}
