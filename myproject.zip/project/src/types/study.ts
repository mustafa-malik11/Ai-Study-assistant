export interface QuizQuestion {
  question: string;
  options: string[];
  answerIndex: number;
}

export interface StudyResponse {
  explanation: string;
  realWorldExample: string;
  quiz: QuizQuestion[];
}

export interface StudyError {
  error: string;
}
