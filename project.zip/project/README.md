# AI Study Assistant

An AI-powered web app that helps students understand any topic in seconds. Enter a subject and the assistant explains it in simple language, gives a real-world example, and generates a 5-question quiz to practice — all powered by OpenAI.

## The problem it solves

Students often hit a wall when textbooks and lectures jump straight into dense, jargon-heavy explanations. A single unclear paragraph can stall an entire study session. **AI Study Assistant** breaks that wall down:

- It **translates complex topics into plain language** so anyone can follow along.
- It **anchors each topic with a real-world example** so abstract ideas finally click.
- It **turns passive reading into active practice** with five auto-generated quiz questions, complete with answers and explanations.

## Features

- **Any topic, on demand** — type whatever you're studying, from photosynthesis to the French Revolution.
- **Simple explanation** — 2–4 short paragraphs written for students, not professors.
- **Real-world example** — one concrete scenario that makes the concept tangible.
- **5-question practice quiz** — multiple choice with four options, instant scoring, and per-question explanations.
- **Copy response** — one click copies the full explanation, example, and quiz to your clipboard.
- **Loading animation** — a polished skeleton + pulse state while the AI is thinking.
- **Recent topics** — your last few searches are saved locally for quick re-runs.
- **Responsive design** — looks great from phone to desktop.

## How the AI feature works

1. The student enters a topic on the assistant page.
2. The browser sends a `POST /api/study` request to a Vercel serverless function.
3. The serverless function calls the **OpenAI Chat Completions API** (`gpt-4o-mini`) using this system prompt:

   > "You are an AI Study Assistant. Explain topics in simple language for students, provide real-world examples, and generate 5 quiz questions for practice."

4. The function instructs the model to return **strict JSON** containing the explanation, a real-world example, and exactly 5 quiz questions (each with 4 options, a correct-answer index, and an explanation).
5. The serverless function forwards the parsed JSON back to the browser, keeping the `OPENAI_API_KEY` server-side so it is never exposed to the client.
6. The React app renders the explanation, the example, and an interactive quiz with scoring.

## Technologies used

- **React 18** + **TypeScript** — UI and type safety
- **Vite** — fast dev server and build
- **Tailwind CSS** — styling and design system
- **lucide-react** — icons
- **OpenAI API** — topic explanations and quiz generation
- **Vercel Serverless Functions** — secure server-side proxy for OpenAI

## Project structure

```
.
├── api/
│   └── study.ts            # Vercel serverless function (OpenAI proxy)
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── CopyButton.tsx
│   │   ├── Footer.tsx
│   │   ├── Header.tsx
│   │   ├── Home.tsx        # Landing page
│   │   ├── LoadingState.tsx
│   │   ├── Quiz.tsx
│   │   ├── StudyAssistant.tsx  # Main study flow
│   │   └── StudyResult.tsx
│   ├── lib/
│   │   └── studyApi.ts     # Client API helper
│   ├── types/
│   │   └── study.ts        # Shared types
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── index.html
├── tailwind.config.js
├── postcss.config.js
├── vite.config.ts
├── tsconfig.json
├── vercel.json
└── package.json
```

## Installation

### Prerequisites

- Node.js 18+
- An OpenAI API key from <https://platform.openai.com/api-keys>

### Local development

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd ai-study-assistant

# 2. Install dependencies
npm install

# 3. Add your OpenAI key
cp .env.example .env
#   then edit .env and set OPENAI_API_KEY=sk-...

# 4. Start the dev server
npm run dev
```

The app runs at <http://localhost:5173>. The `/api/study` endpoint is served by Vercel's local functions when you run `vercel dev`, or you can deploy to Vercel to test the full flow.

### Production build

```bash
npm run build      # outputs to dist/
npm run preview    # preview the production build locally
```

## Deployment

### Deploy to Vercel

1. Push the project to GitHub.
2. Go to <https://vercel.com/new> and import the repository.
3. Add an environment variable: `OPENAI_API_KEY` = your key (Project Settings → Environment Variables).
4. Deploy. Vercel auto-detects Vite and serves `/api/study` as a serverless function.

### Environment variables

| Name              | Description                          | Where                |
| ----------------- | ------------------------------------ | -------------------- |
| `OPENAI_API_KEY`  | Your OpenAI API key (server-side only) | Vercel Project Settings |

## License

MIT — free to use, modify, and share.
