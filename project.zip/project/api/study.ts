// Vercel Serverless Function — proxies study requests to OpenAI.
// Keeps the OpenAI API key server-side so it is never exposed to the browser.

const SYSTEM_PROMPT =
  'You are an AI Study Assistant. Explain topics in simple language for students, provide real-world examples, and generate 5 quiz questions for practice.';

const USER_INSTRUCTIONS = `Explain the given study topic for a student.
Return ONLY valid JSON (no markdown, no code fences) with this exact shape:
{
  "topic": string,
  "explanation": string,            // 2-4 short paragraphs in simple language
  "real_world_example": string,      // one concrete real-world example
  "quiz": [                           // exactly 5 questions
    {
      "question": string,
      "options": [string, string, string, string],  // exactly 4 options
      "answer_index": number,          // 0-based index of the correct option
      "explanation": string            // why the answer is correct
    }
  ]
}
Keep language friendly and accessible. Make quiz options plausible but only one correct.`;

interface OpenAIChatResponse {
  choices?: Array<{ message?: { content?: string } }>;
  error?: { message?: string };
}

export default async function handler(req: { method?: string; body?: { topic?: string } }, res: {
  status(code: number): {
    json(body: unknown): void;
    setHeader(name: string, value: string): unknown;
    end(): void;
  };
}) {
  if (req.method === 'OPTIONS') {
    return res.status(200).setHeader('Access-Control-Allow-Origin', '*').end();
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const topic = typeof req.body?.topic === 'string' ? req.body.topic.trim() : '';
  if (!topic) {
    return res.status(400).json({ error: 'A "topic" string is required.' });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'OpenAI API key is not configured on the server.' });
  }

  try {
    const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        temperature: 0.5,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: `${USER_INSTRUCTIONS}\n\nTopic: ${topic}` },
        ],
      }),
    });

    if (!upstream.ok) {
      const errBody = (await upstream.json().catch(() => null)) as OpenAIChatResponse | null;
      const message = errBody?.error?.message ?? `OpenAI request failed (${upstream.status}).`;
      return res.status(502).json({ error: message });
    }

    const data = (await upstream.json()) as OpenAIChatResponse;
    const content = data.choices?.[0]?.message?.content;
    if (!content) {
      return res.status(502).json({ error: 'OpenAI returned an empty response.' });
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(content);
    } catch {
      return res.status(502).json({ error: 'OpenAI response was not valid JSON.' });
    }

    return res.status(200).setHeader('Access-Control-Allow-Origin', '*').json(parsed);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unexpected server error.';
    return res.status(500).json({ error: message });
  }
}
