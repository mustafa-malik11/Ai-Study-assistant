import { useState } from 'react';
import Header from '@/components/Header';
import Home from '@/components/Home';
import StudyAssistant from '@/components/StudyAssistant';
import Footer from '@/components/Footer';

type View = 'home' | 'assistant';

export default function App() {
  const [view, setView] = useState<View>('home');

  return (
    <div className="flex min-h-screen flex-col">
      <Header onLogoClick={() => setView('home')} />
      <main className="flex-1">
        {view === 'home' ? (
          <Home onStart={() => setView('assistant')} />
        ) : (
          <StudyAssistant onHome={() => setView('home')} />
        )}
      </main>
      <Footer />
    </div>
  );
}
