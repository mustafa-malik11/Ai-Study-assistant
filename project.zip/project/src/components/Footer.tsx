import { GraduationCap } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-ink-100 bg-white">
      <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-3 px-4 py-6 sm:flex-row sm:px-6">
        <div className="flex items-center gap-2 text-sm text-ink-500">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-600 text-white">
            <GraduationCap className="h-4 w-4" />
          </span>
          <span className="font-medium text-ink-700">AI Study Assistant</span>
        </div>
        <p className="text-xs text-ink-400">
          Built with React, Tailwind CSS &amp; OpenAI. For learning purposes.
        </p>
      </div>
    </footer>
  );
}
