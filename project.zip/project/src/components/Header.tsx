import { GraduationCap } from 'lucide-react';

interface HeaderProps {
  onLogoClick: () => void;
}

export default function Header({ onLogoClick }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-ink-100/80 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4 sm:px-6">
        <button
          onClick={onLogoClick}
          className="group flex items-center gap-2.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded-lg"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 text-white shadow-soft transition-transform duration-200 group-hover:scale-105">
            <GraduationCap className="h-5 w-5" />
          </span>
          <span className="font-display text-lg font-bold tracking-tight text-ink-900">
            AI Study Assistant
          </span>
        </button>
        <a
          href="https://github.com"
          target="_blank"
          rel="noreferrer"
          className="hidden text-sm font-medium text-ink-500 transition-colors hover:text-ink-900 sm:block"
        >
          Built for students
        </a>
      </div>
    </header>
  );
}
