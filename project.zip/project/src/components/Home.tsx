import { ArrowRight, BookOpen, Lightbulb, ListChecks, Sparkles, Target } from 'lucide-react';

interface HomeProps {
  onStart: () => void;
}

const SUGGESTED_TOPICS = [
  'Photosynthesis',
  'Newton’s Laws of Motion',
  'The French Revolution',
  'Supply and Demand',
  'Binary Numbers',
  'Mitochondria',
];

export default function Home({ onStart }: HomeProps) {
  return (
    <div className="relative overflow-hidden">
      {/* ambient background */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-24 left-1/2 h-72 w-[40rem] -translate-x-1/2 rounded-full bg-brand-200/40 blur-3xl" />
        <div className="absolute right-0 top-40 h-64 w-64 rounded-full bg-accent-200/40 blur-3xl" />
      </div>

      <section className="mx-auto max-w-5xl px-4 pb-10 pt-16 sm:px-6 sm:pt-24">
        <div className="flex justify-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/70 px-3.5 py-1.5 text-sm font-medium text-brand-700 shadow-soft backdrop-blur">
            <Sparkles className="h-4 w-4" />
            Powered by OpenAI
          </span>
        </div>

        <h1 className="mt-6 text-center font-display text-4xl font-extrabold tracking-tight text-ink-900 text-balance sm:text-6xl">
          AI Study Assistant
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-center text-lg leading-relaxed text-ink-600 text-balance">
          Studying shouldn’t feel like decoding a textbook. Type any topic and get a clear,
          simple explanation, a real-world example that actually makes sense, and five
          practice quiz questions to lock in what you learned.
        </p>

        <div className="mt-8 flex justify-center">
          <button onClick={onStart} className="btn-primary px-6 py-3.5 text-base">
            Start studying
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>

        {/* problem solved */}
        <div className="mt-16 grid gap-4 sm:grid-cols-3">
          <FeatureCard
            icon={<BookOpen className="h-5 w-5" />}
            title="Simple explanations"
            body="Complex topics broken down into plain language anyone can follow — no jargon walls."
          />
          <FeatureCard
            icon={<Lightbulb className="h-5 w-5" />}
            title="Real-world examples"
            body="Every topic comes with a concrete example so abstract ideas finally click."
          />
          <FeatureCard
            icon={<ListChecks className="h-5 w-5" />}
            title="Instant quiz practice"
            body="Five auto-generated questions with answers and explanations to test yourself."
          />
        </div>
      </section>

      {/* how it works */}
      <section className="mx-auto max-w-5xl px-4 pb-20 sm:px-6">
        <div className="card p-6 sm:p-8">
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-brand-600" />
            <h2 className="font-display text-xl font-bold text-ink-900">How it works</h2>
          </div>
          <ol className="mt-5 grid gap-5 sm:grid-cols-3">
            <Step n={1} title="Enter a topic" body="Anything you’re studying — from gravity to the Great Wall." />
            <Step n={2} title="Get the breakdown" body="A simple explanation plus a real-world example, in seconds." />
            <Step n={3} title="Practice & copy" body="Take the 5-question quiz, then copy the whole response anywhere." />
          </ol>

          <div className="mt-7 border-t border-ink-100 pt-6">
            <p className="text-sm font-medium text-ink-500">Try a topic to get started:</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {SUGGESTED_TOPICS.map((t) => (
                <button key={t} onClick={onStart} className="chip">
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div className="card p-5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-glow">
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-100 text-brand-700">
        {icon}
      </span>
      <h3 className="mt-4 font-display text-base font-semibold text-ink-900">{title}</h3>
      <p className="mt-1.5 text-sm leading-relaxed text-ink-600">{body}</p>
    </div>
  );
}

function Step({ n, title, body }: { n: number; title: string; body: string }) {
  return (
    <li className="relative">
      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ink-900 text-sm font-bold text-white">
        {n}
      </span>
      <h3 className="mt-3 font-semibold text-ink-900">{title}</h3>
      <p className="mt-1 text-sm leading-relaxed text-ink-600">{body}</p>
    </li>
  );
}
