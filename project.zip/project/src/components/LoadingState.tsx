import { Sparkles } from 'lucide-react';

export default function LoadingState({ topic }: { topic: string }) {
  return (
    <div className="card animate-fade-in p-6 sm:p-8">
      <div className="flex items-center gap-3">
        <div className="relative flex h-10 w-10 items-center justify-center">
          <span className="absolute inset-0 rounded-full bg-brand-400/40 animate-pulse-ring" />
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-600 text-white">
            <Sparkles className="h-5 w-5" />
          </span>
        </div>
        <div>
          <p className="font-semibold text-ink-900">Studying “{topic}”…</p>
          <p className="text-sm text-ink-500">Crafting an explanation, an example, and 5 quiz questions.</p>
        </div>
      </div>

      <div className="mt-6 space-y-5">
        <SkeletonBlock lines={4} />
        <SkeletonBlock lines={3} accent />
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="relative overflow-hidden rounded-xl border border-ink-100 bg-ink-50 p-4">
              <div className="h-3 w-2/3 rounded bg-ink-200" />
              <div className="mt-3 grid grid-cols-2 gap-2">
                <div className="h-3 rounded bg-ink-200" />
                <div className="h-3 rounded bg-ink-200" />
              </div>
              <span className="shimmer-bg absolute inset-0 -translate-x-full animate-shimmer" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SkeletonBlock({ lines, accent = false }: { lines: number; accent?: boolean }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-ink-100 bg-ink-50 p-4">
      <div className="space-y-2.5">
        {Array.from({ length: lines }).map((_, i) => (
          <div
            key={i}
            className={`h-3 rounded ${accent ? 'bg-accent-200' : 'bg-ink-200'} ${
              i === lines - 1 ? 'w-1/2' : 'w-full'
            }`}
          />
        ))}
      </div>
      <span className="shimmer-bg absolute inset-0 -translate-x-full animate-shimmer" />
    </div>
  );
}
