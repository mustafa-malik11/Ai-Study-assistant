import { useState } from 'react';
import { Check, ChevronDown, X } from 'lucide-react';
import type { QuizQuestion } from '@/types/study';

interface QuizProps {
  quiz: QuizQuestion[];
}

export default function Quiz({ quiz }: QuizProps) {
  const [answers, setAnswers] = useState<(number | null)[]>(quiz.map(() => null));
  const [submitted, setSubmitted] = useState(false);

  const score = answers.reduce<number>((acc, ans, i) => (ans === quiz[i].answerIndex ? acc + 1 : acc), 0);
  const allAnswered = answers.every((a) => a !== null);

  function selectAnswer(qIndex: number, optionIndex: number) {
    if (submitted) return;
    setAnswers((prev) => prev.map((a, i) => (i === qIndex ? optionIndex : a)));
  }

  function reset() {
    setAnswers(quiz.map(() => null));
    setSubmitted(false);
  }

  return (
    <div className="space-y-4">
      {quiz.map((q, qIndex) => {
        const selected = answers[qIndex];
        return (
          <QuizCard
            key={qIndex}
            q={q}
            qIndex={qIndex}
            selected={selected}
            submitted={submitted}
            onSelect={(opt) => selectAnswer(qIndex, opt)}
          />
        );
      })}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {submitted ? (
          <p className="font-semibold text-ink-900">
            You scored <span className="text-brand-700">{score}</span> / {quiz.length}
            {score === quiz.length ? ' — perfect!' : score >= quiz.length - 1 ? ' — great job!' : ' — keep practicing.'}
          </p>
        ) : (
          <p className="text-sm text-ink-500">
            {allAnswered ? 'Ready to check your answers.' : 'Answer all questions to submit.'}
          </p>
        )}
        <div className="flex gap-2">
          {submitted && (
            <button onClick={reset} className="btn-ghost">
              Try again
            </button>
          )}
          <button
            onClick={() => setSubmitted(true)}
            disabled={!allAnswered || submitted}
            className="btn-primary"
          >
            Check answers
          </button>
        </div>
      </div>
    </div>
  );
}

interface QuizCardProps {
  q: QuizQuestion;
  qIndex: number;
  selected: number | null;
  submitted: boolean;
  onSelect: (optionIndex: number) => void;
}

function QuizCard({ q, qIndex, selected, submitted, onSelect }: QuizCardProps) {
  const [open, setOpen] = useState(true);
  const correct = selected === q.answerIndex;

  return (
    <div className="card overflow-hidden">
      <div className="flex items-start gap-3 p-4 sm:p-5">
        <span className="mt-0.5 flex h-7 w-7 flex-none items-center justify-center rounded-lg bg-brand-100 text-sm font-bold text-brand-700">
          {qIndex + 1}
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-medium text-ink-900">{q.question}</p>
          <div className="mt-3 grid gap-2">
            {q.options.map((opt, optIndex) => {
              const isSelected = selected === optIndex;
              const isCorrect = optIndex === q.answerIndex;
              const showCorrect = submitted && isCorrect;
              const showWrong = submitted && isSelected && !isCorrect;

              return (
                <button
                  key={optIndex}
                  onClick={() => onSelect(optIndex)}
                  disabled={submitted}
                  className={`flex items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5 text-left text-sm transition-all duration-200 ${
                    showCorrect
                      ? 'border-brand-500 bg-brand-50 text-brand-800'
                      : showWrong
                        ? 'border-red-300 bg-red-50 text-red-700'
                        : isSelected
                          ? 'border-brand-400 bg-brand-50 text-ink-900'
                          : 'border-ink-200 bg-white text-ink-700 hover:border-ink-300 hover:bg-ink-50'
                  } ${submitted ? 'cursor-default' : 'cursor-pointer'}`}
                >
                  <span>{opt}</span>
                  {showCorrect && <Check className="h-4 w-4 flex-none text-brand-600" />}
                  {showWrong && <X className="h-4 w-4 flex-none text-red-500" />}
                </button>
              );
            })}
          </div>

          {submitted && (
            <div className="mt-3">
              <button
                onClick={() => setOpen((o) => !o)}
                className="flex items-center gap-1 text-sm font-medium text-ink-500 hover:text-ink-900"
              >
                <ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} />
                {correct ? 'Correct' : 'Explanation'}
              </button>
              {open && (
                <p className="mt-2 rounded-lg bg-ink-50 p-3 text-sm text-ink-600">
                  {correct ? '✓ ' : ''}
                  {q.explanation}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
