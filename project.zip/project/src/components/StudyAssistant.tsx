import { useState } from 'react';
import { AlertCircle, ArrowLeft, Search, Sparkles } from 'lucide-react';
import { fetchStudyTopic } from '@/lib/studyApi';
import type { StudyResponse } from '@/types/study';
import LoadingState from './LoadingState';
import StudyResult from './StudyResult';

interface StudyAssistantProps {
  onHome: () => void;
}

const RECENT_TOPICS_KEY = 'ai-study-recent-topics';

function loadRecentTopics(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_TOPICS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.slice(0, 6) : [];
  } catch {
    return [];
  }
}

function saveRecentTopic(topic: string) {
  try {
    const existing = loadRecentTopics();
    const next = [topic, ...existing.filter((t) => t.toLowerCase() !== topic.toLowerCase())].slice(0, 6);
    localStorage.setItem(RECENT_TOPICS_KEY, JSON.stringify(next));
  } catch {
    // ignore storage errors
  }
}

type Status = 'idle' | 'loading' | 'success' | 'error';

export default function StudyAssistant({ onHome }: StudyAssistantProps) {
  const [topic, setTopic] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [result, setResult] = useState<StudyResponse | null>(null);
  const [error, setError] = useState<string>('');
  const [recentTopics, setRecentTopics] = useState<string[]>(() => loadRecentTopics());

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = topic.trim();
    if (!trimmed || status === 'loading') return;

    setStatus('loading');
    setError('');
    setResult(null);

    try {
      const data = await fetchStudyTopic(trimmed);
      setResult(data);
      saveRecentTopic(trimmed);
      setRecentTopics(loadRecentTopics());
      setStatus('success');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong. Please try again.';
      setError(message);
      setStatus('error');
    }
  }

  function reset() {
    setStatus('idle');
    setResult(null);
    setError('');
    setTopic('');
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <button
        onClick={onHome}
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-ink-500 transition-colors hover:text-ink-900"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to home
      </button>

      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold tracking-tight text-ink-900 sm:text-4xl">
          What do you want to learn?
        </h1>
        <p className="mt-2 text-ink-600">
          Enter any topic and the AI will explain it simply, give a real-world example, and quiz you.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="card p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-400" />
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Photosynthesis, World War II, Fractions…"
              className="input-field pl-11"
              autoFocus
              disabled={status === 'loading'}
              aria-label="Study topic"
            />
          </div>
          <button type="submit" className="btn-primary sm:px-6" disabled={status === 'loading' || !topic.trim()}>
            <Sparkles className="h-5 w-5" />
            Explain it
          </button>
        </div>

        {recentTopics.length > 0 && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium uppercase tracking-wide text-ink-400">Recent</span>
            {recentTopics.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTopic(t)}
                className="chip"
                disabled={status === 'loading'}
              >
                {t}
              </button>
            ))}
          </div>
        )}
      </form>

      <div className="mt-6">
        {status === 'loading' && <LoadingState topic={topic.trim()} />}

        {status === 'error' && (
          <div className="card animate-fade-in border-red-200 bg-red-50/60 p-5">
            <div className="flex items-start gap-3">
              <AlertCircle className="mt-0.5 h-5 w-5 flex-none text-red-500" />
              <div className="flex-1">
                <p className="font-semibold text-red-800">Couldn’t generate a response</p>
                <p className="mt-1 text-sm text-red-700">{error}</p>
                <button onClick={reset} className="btn-ghost mt-4 border-red-200 text-red-700 hover:bg-red-100">
                  Try again
                </button>
              </div>
            </div>
          </div>
        )}

        {status === 'success' && result && <StudyResult result={result} />}
      </div>
    </div>
  );
}
