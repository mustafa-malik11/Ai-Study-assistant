import { BookOpen, Lightbulb, ListChecks } from 'lucide-react';
import type { StudyResponse } from '@/types/study';
import CopyButton from './CopyButton';
import Quiz from './Quiz';

interface StudyResultProps {
  result: StudyResponse;
}

function buildCopyText(result: StudyResponse): string {
  const lines: string[] = [];
  lines.push(`Topic: ${result.topic}`);
  lines.push('');
  lines.push('EXPLANATION');
  lines.push(result.explanation);
  lines.push('');
  lines.push('REAL-WORLD EXAMPLE');
  lines.push(result.realWorldExample);
  lines.push('');
  lines.push('QUIZ (5 questions)');
  result.quiz.forEach((q, i) => {
    lines.push(`${i + 1}. ${q.question}`);
    q.options.forEach((o, j) => lines.push(`   ${String.fromCharCode(65 + j)}) ${o}`));
    lines.push(`   Answer: ${String.fromCharCode(65 + q.answerIndex)} — ${q.explanation}`);
    lines.push('');
  });
  return lines.join('\n');
}

export default function StudyResult({ result }: StudyResultProps) {
  const copyText = buildCopyText(result);

  return (
    <div className="space-y-5 animate-fade-up">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium uppercase tracking-wide text-brand-600">Result for</p>
          <h2 className="font-display text-2xl font-bold text-ink-900 sm:text-3xl">{result.topic}</h2>
        </div>
        <CopyButton text={copyText} />
      </div>

      <section className="card p-5 sm:p-6">
        <div className="mb-3 flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-brand-600" />
          <h3 className="font-display text-lg font-semibold text-ink-900">Simple explanation</h3>
        </div>
        <p className="whitespace-pre-line leading-relaxed text-ink-700">{result.explanation}</p>
      </section>

      <section className="card border-accent-200 bg-accent-50/40 p-5 sm:p-6">
        <div className="mb-3 flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-accent-600" />
          <h3 className="font-display text-lg font-semibold text-ink-900">Real-world example</h3>
        </div>
        <p className="whitespace-pre-line leading-relaxed text-ink-700">{result.realWorldExample}</p>
      </section>

      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <ListChecks className="h-5 w-5 text-brand-600" />
          <h3 className="font-display text-lg font-semibold text-ink-900">Practice quiz — 5 questions</h3>
        </div>
        <Quiz quiz={result.quiz} />
      </section>
    </div>
  );
}
