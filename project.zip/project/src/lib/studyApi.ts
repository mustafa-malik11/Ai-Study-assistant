import type { StudyResponse, ApiError } from '@/types/study';

const SYSTEM_PROMPT =
  'You are an AI Study Assistant. Explain topics in simple language for students, provide real-world examples, and generate 5 quiz questions for practice.';

interface OpenAIResponse {
  topic: string;
  explanation: string;
  real_world_example: string;
  quiz: Array<{
    question: string;
    options: string[];
    answer_index: number;
    explanation: string;
  }>;
}

function toStudyResponse(data: OpenAIResponse): StudyResponse {
  return {
    topic: data.topic,
    explanation: data.explanation,
    realWorldExample: data.real_world_example,
    quiz: data.quiz.map((q) => ({
      question: q.question,
      options: q.options,
      answerIndex: q.answer_index,
      explanation: q.explanation,
    })),
  };
}

export async function fetchStudyTopic(topic: string, signal?: AbortSignal): Promise<StudyResponse> {
  const res = await fetch('/api/study', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ topic }),
    signal,
  });

  if (!res.ok) {
    let message = `Request failed with status ${res.status}`;
    try {
      const err = (await res.json()) as ApiError;
      if (err.error) message = err.error;
    } catch {
      // ignore parse error, keep default message
    }
    throw new Error(message);
  }

  const data = (await res.json()) as OpenAIResponse;
  return toStudyResponse(data);
}

export { SYSTEM_PROMPT };
