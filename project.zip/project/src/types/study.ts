export interface QuizQuestion {
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface StudyResponse {
  topic: string;
  explanation: string;
  realWorldExample: string;
  quiz: QuizQuestion[];
}

export interface ApiError {
  error: string;
}
